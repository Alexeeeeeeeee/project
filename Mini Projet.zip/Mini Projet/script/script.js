// date actuelle
var date = new Date(Date.now());
var dateString = new Date(date.getTime() - (date.getTimezoneOffset() * 60000 ))
                    .toISOString()
                    .split("T")[0];
var dataINPUT = {
  "info": [
      {"infoID": "conducteur", "title": "Nom du conducteur", "type": "text", "placeholder": "ex: Tristan", "value": "", "required": "required", "col": "half"},
      {"infoID": "accompagnant", "title": "Nom de l'accompagnant", "type": "text", "placeholder": "ex: Papa", "value": "", "required": "required", "col": "half"},
      {"infoID": "date", "title": "Date", "type": "date", "placeholder": "", "value": `${dateString}`, "required": "required", "col": ""},
      {"infoID": "depart", "title": "Départ", "type": "time", "placeholder": "", "value": "", "required": "required", "col": "half"},
      {"infoID": "arrivee", "title": "Arrivée", "type": "time", "placeholder": "", "value": "", "required": "required", "col": "half"},
      {"infoID": "km", "title": "Km", "type": "number", "placeholder": "10 Km", "value": "", "required": "required", "col": ""}
  ],
  "meteo": [{ "meteoID": 0, "meteo": "Ensoleillé/Clair" }, { "meteoID": 1, "meteo": "Nuageux" }, { "meteoID": 2, "meteo": "Pluvieux" }, { "meteoID": 3, "meteo": "Brouillard" }, { "meteoID": 4, "meteo": "Orageux" }, { "meteoID": 5, "meteo": "Neigeux" }],
  "trafic": [{ "traficID": 0, "trafic": "Normal" }, { "traficID": 1, "trafic": "Dense" }, { "traficID": 2, "trafic": "Très dense" }],
  "man": [
      {"manID": 1, "name": "En épi à droite", "jsonID": "en_epi_a_droite"},
      {"manID": 2, "name": "En épi à gauche", "jsonID": "en_epi_a_gauche"},
      {"manID": 3, "name": "Bataille droite", "jsonID": "bataille_droite"},
      {"manID": 4, "name": "Bataille gauche", "jsonID": "bataille_gauche"},
      {"manID": 5, "name": "Créneau droit", "jsonID": "creneau_droit"},
      {"manID": 6, "name": "Créneau gauche", "jsonID": "creneau_gauche"}
  ],
  "note": [
      {"noteID": 1, "title": "Adaptation de l'allure", "name": "allure"},
      {"noteID": 2, "title": "Distances de sécurité", "name": "distance"},
      {"noteID": 3, "title": "Anticipation", "name": "anticipation"},
      {"noteID": 4, "title": "Maniablilite", "name": "maniabilite"},
      {"noteID": 5, "title": "Controles", "name": "controles"},
      {"noteID": 6, "title": "Courtoisie", "name": "courtoisie"}
  ]
}
// Ajout des données en local quand envoie du formulaire
function addToLocalData() {
  // Calcul du temps
  var date_set = new Date(document.getElementById('date').value);
  date_set.setHours(parseInt(document.getElementById('depart').value) + 1, parseInt(document.getElementById('depart').value.slice(3)), 00);
  var date_arrivee = new Date(document.getElementById('date').value);
  date_arrivee.setHours(parseInt(document.getElementById('arrivee').value) + 1, parseInt(document.getElementById('arrivee').value.slice(3)), 00);
  // Enregistrement des données du form dans une structure json
  const dataForm = {
    date_dep: date_set,
    time: ((date_arrivee.getTime() - date_set.getTime()) / 1000) / 60,
    km: parseInt(document.getElementById('km').value),
    meteo: parseInt(document.getElementById('meteo').value),
    trafic: parseInt(document.getElementById('trafic').value),
    accompagnant: document.getElementById('accompagnant').value,
    manoeuvres: {
      en_epi_a_droite: parseInt(document.getElementById('man1').value),
      en_epi_a_gauche: parseInt(document.getElementById('man2').value),
      bataille_droite: parseInt(document.getElementById('man3').value),
      bataille_gauche: parseInt(document.getElementById('man4').value),
      creneau_droit: parseInt(document.getElementById('man5').value),
      creneau_gauche: parseInt(document.getElementById('man6').value),
    },
    notation: {
      adaptation_allure: parseInt(document.querySelector('input[name=allure]:checked').value),
      distances: parseInt(document.querySelector('input[name=distance]:checked').value),
      anticipation: parseInt(document.querySelector('input[name=anticipation]:checked').value),
      maniablilite: parseInt(document.querySelector('input[name=maniabilite]:checked').value),
      controles: parseInt(document.querySelector('input[name=controles]:checked').value),
      courtoisie: parseInt(document.querySelector('input[name=courtoisie]:checked').value)
    },
    commentaire: document.getElementById('commentaire').value,
  };
  // Si data n'est pas déjà enregistré en local
  let userData = []
  let conducteur = document.getElementById('conducteur').value;
  let data = JSON.parse(localStorage.getItem(conducteur));
  if (data == null) {
    userData[0] = dataForm;
    // actualisation des données
    localStorage.setItem(conducteur, JSON.stringify(userData));
    alert("Trajet enregistré !\nPremier trajet enregistré avec succès pour "+ conducteur);
  }
  // Si data non null, on ajoute à la suite
  else {
    data[data.length] = dataForm;
    // actualisation des données
    localStorage.setItem(conducteur, JSON.stringify(data));
    alert("Trajet enregistré !\n"+data.length+"ième trajet enregistré avec succès pour "+ conducteur);
  }
}
function afficherDataConducteur() {
  let conducteur = document.getElementById('search').value;
  let UserData = JSON.parse(localStorage.getItem(conducteur));
  let createtable = document.getElementById("create_table");
  if (UserData != null) {
    createtable.innerHTML = 
    `<h2>Résumé des trajets :</h2>
    <div class="scroll">
      <table id="tab_resume">
        <thead><tr><th>N°</th><th>Date</th><th>Accompagnant</th><th>Durée</th><th>Distance</th></thead>
        <tbody id="tbody"></tbody>
      </table>
    </div><br><br>
    <div class="scroll">
      <table id="tab_resume2">
        <thead><tr><th>N°</th><th>Météo</th><th>Trafic</th><th>Manoeuvres réalisées</th><th>Note</th></tr></thead>
        <tbody id="tbody2"></tbody>
      </table>
    </div><br><br>
    <div class="scroll">
      <table id="commentaire">
        <thead><tr><th>N°</th><th>Commentaire</th></tr></thead>
        <tbody id="tbody3"></tbody>
      </table>
    </div><br><br>`;
    var tbody = document.getElementById("tbody");
    var note = 0; var man = 0; var distance = 0; var trajet = 1; var temps = 0;
    var xkm = [];
    var xman = [];
    var ykm = [];
    var pieData = [0,0,0,0,0,0];
    for (let index = 0; index < UserData.length; index++) {
      var nb_manoeuvre = (UserData[index].manoeuvres.en_epi_a_droite + UserData[index].manoeuvres.en_epi_a_gauche + UserData[index].manoeuvres.bataille_droite + UserData[index].manoeuvres.bataille_gauche + UserData[index].manoeuvres.creneau_droit + UserData[index].manoeuvres.creneau_gauche)
      var str = "";
      var manoe = {
        "man": [
          {"nb": UserData[index].manoeuvres.en_epi_a_droite, "sing": "épi à droite", "plu": "épis à droite"},
          {"nb": UserData[index].manoeuvres.en_epi_a_gauche, "sing": "épi à gauche", "plu": "épis à gauche"},
          {"nb": UserData[index].manoeuvres.bataille_droite, "sing": "bataille droite", "plu": "batailles droite"},
          {"nb": UserData[index].manoeuvres.bataille_gauche, "sing": "bataille gauche", "plu": "batailles gauche"},
          {"nb": UserData[index].manoeuvres.creneau_droit, "sing": "créneau droit", "plu": "créneaux droit"},
          {"nb": UserData[index].manoeuvres.creneau_gauche, "sing": "créneau gauche", "plu": "créneaux gauche"}
      ]};
      manoe.man.forEach(function (item, index) {
        if (item.nb == 1) {
          str += `${item.nb} ${item.sing},<br>`;
        } else if (item.nb > 1) {
          str += `${item.nb} ${item.plu},<br>`;
        }
      }); str = str.slice(0, -5);
      if (nb_manoeuvre == 0) {
        str = "/";
      }
      var note_moyenne = (UserData[index].notation.adaptation_allure + UserData[index].notation.distances + UserData[index].notation.anticipation + UserData[index].notation.maniablilite + UserData[index].notation.controles + UserData[index].notation.courtoisie) / 6
      man += nb_manoeuvre; note += note_moyenne; temps += UserData[index].time; distance += UserData[index].km; xkm.push(UserData[index].km); ykm.push(index+1); xman.push(nb_manoeuvre);
      pieData[0] += UserData[index].notation.adaptation_allure/(UserData.length); 
      pieData[1] +=  UserData[index].notation.distances/(UserData.length);
      pieData[2] +=  UserData[index].notation.anticipation/(UserData.length);
      pieData[3] +=  UserData[index].notation.maniablilite/(UserData.length);
      pieData[4] += UserData[index].notation.controles/(UserData.length);
      pieData[5] += UserData[index].notation.courtoisie/(UserData.length);
      var x = "";
      if (index % 2 == 0) {x="";} else {x = ` class="demi" `;}
      tbody.innerHTML += `<tr${x}><td>${index + 1}</td><td>${UserData[index].date_dep.slice(0,10).split('-').reverse().join('/')}</td><td>${UserData[index].accompagnant}</td><td>${UserData[index].time} min</td><td>${UserData[index].km} km</td></tr>`;
      tbody2.innerHTML += `<tr${x}><td>${index + 1}</td><td>${dataINPUT.meteo[UserData[index].meteo].meteo}</td><td>${dataINPUT.trafic[UserData[index].trafic].trafic}</td><td>${str}</td><td>${note_moyenne.toFixed(1)}</td></tr>`;
      if (UserData[index].commentaire != "") {
        tbody3.innerHTML += `<tr${x}><td>${index + 1}</td><td>${UserData[index].commentaire}</td></tr>`;
      } else {tbody3.innerHTML += `<tr${x}><td>${index + 1}</td><td>/</td></tr>`;}
    }
    // Ajout de la table total
    createtable.innerHTML += 
    `<h2>Totaux et moyennes :</h2>
    <div class="scroll">
      <table id=\"table2\">
        <thead id=\"thead2\"><tr><th>Nombre de trajets</th><th>Durée total</th><th>Distance total</th><th>Note moyenne</th><th>Nombre de manoeuvres réalisées</th></tr></thead>
        <tbody id=\"display-table2\"><tr><td>${UserData.length}</td><td>${temps} min</td><td>${distance} km</td><td>${(note/UserData.length).toFixed(1)}</td><td>${man}</td></tr></tbody>
      </table>
    </div><br><br>`;
    // Ajout des graphs
    createtable.innerHTML += `
    <h2>Graphiques :</h2>
    <div class="row">
      <div class="col-half">
        <canvas id="graphkm" style="width:100%;max-width:700px"></canvas>
      </div>
      <div class="col-half">
        <canvas id="mano" style="width:100%;max-width:700px"></canvas>
      </div>
    </div><br><br>
    <div class="row">
      <canvas id="notation" style="width:100%;max-width:500px"></canvas>
    </div>
    <br>`;
    new Chart("graphkm", {
      type: "line",
      data: {
        labels: ykm,
        datasets: [{
          fill: false,
          pointRadius: 1,
          borderColor: "rgba(255,0,0,0.5)",
          data: xkm
        }]
      },    
      options: {
        legend: {display: false},
        title: {
          display: true,
          text: "Evolution de la distance en fonction des trajets",
          fontSize: 16
        }
      }
    });
    new Chart("mano", {
      type: "bar",
      data: {
        labels: ykm,
        datasets: [{
          fill: false,
          pointRadius: 1,
          borderColor: "rgba(255,0,0,0.5)",
          data: xman
        }]
      },    
      options: {
        legend: {display: false},
        title: {
          display: true,
          text: "Evolution du nombre de manoeuvres en fonction des trajets",
          fontSize: 16
        }
      }
    });
    new Chart("notation", {
      type: "pie",
      data: {
        labels: [
          "Adaptation de l'allure",
          "Distances de sécurité",
          "Anticipation",
          "Maniablilite",
          "Controles",
          "Courtoisie"
        ],
        datasets: [{
          label: 'Camanbert des notations',
          data: pieData,
          backgroundColor: [
            "#152A3D", "#1A4857", "#31AA99", "#FFFBA9", "#FF8F44", "#71291A"
          ],
          hoverOffset: 4
        }]
      },    
      options: {
        aspectRatio: 1,
        segmentShowStroke : false,
        animateScale : true,
        title: {
          display: true,
          text: "Répartition des notes",
          fontSize: 16
        }
    }
    });
  }
}
// Suppression des données locales
function clearLocalData() {
  //localStorage.removeItem('userData');
  if (confirm('Êtes-vous bien sûr de vouloir supprimer toutes les trajets sauvegardés en local?')) {
    localStorage.clear();
    alert("Les trajets enregistrés en local ont bien étés supprimés !");
  } else {
    alert("Annualation prise en compte, la démarche n'a pas abouti");
  }
}
function SuprLigne(str) {
  var result = str.split("-");
  var conducteur = result[0];
  var ligne = result[1];
  let UserData = JSON.parse(localStorage.getItem(conducteur));
  if (UserData.length==1) {
    localStorage.removeItem(conducteur);
  } else {
    UserData.splice(ligne, ligne+1);
    localStorage.setItem(conducteur, JSON.stringify(UserData));
  }
}
function addTestValue() {
  const noah = [
    {
        "date_dep": "2023-05-21T15:16:00.000Z",
        "time": 5,
        "km": 5,
        "meteo": 1,
        "trafic": 1,
        "accompagnant": "Richard",
        "manoeuvres": {
            "en_epi_a_droite": 1,
            "en_epi_a_gauche": 0,
            "bataille_droite": 0,
            "bataille_gauche": 0,
            "creneau_droit": 0,
            "creneau_gauche": 0
        },
        "notation": {
            "adaptation_allure": 5,
            "distances": 5,
            "anticipation": 4,
            "maniablilite": 2,
            "controles": 5,
            "courtoisie": 3
        },
        "commentaire": "Très belle conduite"
    },
    {
        "date_dep": "2023-05-21T15:20:00.000Z",
        "time": 4,
        "km": 2,
        "meteo": 1,
        "trafic": 0,
        "accompagnant": "Richard",
        "manoeuvres": {
            "en_epi_a_droite": 0,
            "en_epi_a_gauche": 0,
            "bataille_droite": 0,
            "bataille_gauche": 0,
            "creneau_droit": 1,
            "creneau_gauche": 0
        },
        "notation": {
            "adaptation_allure": 4,
            "distances": 5,
            "anticipation": 3,
            "maniablilite": 4,
            "controles": 4,
            "courtoisie": 5
        },
        "commentaire": "Anticipation en retard sur le reste."
    },
    {
        "date_dep": "2023-05-23T08:23:00.000Z",
        "time": 13,
        "km": 8,
        "meteo": 2,
        "trafic": 2,
        "accompagnant": "Maya",
        "manoeuvres": {
            "en_epi_a_droite": 0,
            "en_epi_a_gauche": 0,
            "bataille_droite": 1,
            "bataille_gauche": 1,
            "creneau_droit": 0,
            "creneau_gauche": 0
        },
        "notation": {
            "adaptation_allure": 4,
            "distances": 4,
            "anticipation": 3,
            "maniablilite": 5,
            "controles": 4,
            "courtoisie": 5
        },
        "commentaire": "Magnifique manoeuvre!"
    }
  ]
  const Tristan = [
    {
        "date_dep": "2023-05-21T15:17:00.000Z",
        "time": 12,
        "km": 9,
        "meteo": 0,
        "trafic": 0,
        "accompagnant": "Olivier",
        "manoeuvres": {
            "en_epi_a_droite": 2,
            "en_epi_a_gauche": 1,
            "bataille_droite": 0,
            "bataille_gauche": 0,
            "creneau_droit": 0,
            "creneau_gauche": 0
        },
        "notation": {
            "adaptation_allure": 4,
            "distances": 2,
            "anticipation": 4,
            "maniablilite": 4,
            "controles": 5,
            "courtoisie": 2
        },
        "commentaire": "La conduite était parfaite, rien à redire."
    },
    {
        "date_dep": "2023-06-05T07:29:00.000Z",
        "time": 480,
        "km": 750,
        "meteo": 2,
        "trafic": 0,
        "accompagnant": "Delphine",
        "manoeuvres": {
            "en_epi_a_droite": 0,
            "en_epi_a_gauche": 0,
            "bataille_droite": 0,
            "bataille_gauche": 1,
            "creneau_droit": 0,
            "creneau_gauche": 0
        },
        "notation": {
            "adaptation_allure": 4,
            "distances": 4,
            "anticipation": 5,
            "maniablilite": 5,
            "controles": 3,
            "courtoisie": 5
        },
        "commentaire": "Trajet pour les vacances relativement calme."
    }
  ]
  const Ethan = [
    {
        "date_dep": "2023-05-21T18:17:00.000Z",
        "time": 64,
        "km": 78,
        "meteo": 4,
        "trafic": 0,
        "accompagnant": "Walter",
        "manoeuvres": {
            "en_epi_a_droite": 0,
            "en_epi_a_gauche": 0,
            "bataille_droite": 1,
            "bataille_gauche": 0,
            "creneau_droit": 0,
            "creneau_gauche": 0
        },
        "notation": {
            "adaptation_allure": 5,
            "distances": 5,
            "anticipation": 5,
            "maniablilite": 5,
            "controles": 5,
            "courtoisie": 5
        },
        "commentaire": "Ethan arrive au terme et ça se voit."
    }
  ]
  if (confirm('Si vous avez déjà des données sous le nom de Noah, Tristan ou Ethan elle seront écrasées ! Êtes vous sûr de vouloir continuer ?')) {
    localStorage.setItem("Noah", JSON.stringify(noah));
    localStorage.setItem("Tristan", JSON.stringify(Tristan));
    localStorage.setItem("Ethan", JSON.stringify(Ethan));
    alert("Les trajets des tests ont bien étés enregistrés !");
  } else {
    alert("Annualation prise en compte, la démarche n'a pas abouti");
  }
}