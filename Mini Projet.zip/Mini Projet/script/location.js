var loc = {
    before: {latitude: 0, longitude: 0},
    after: {latitude: 0, longitude: 0}
}; 
var stopf = false; var count = 0; var res = 0;
function error(err) {
    console.warn(`ERROR(${err.code}): ${err.message}`);
} const options = {
    enableHighAccuracy: true,
    timeout: Infinity,
    maximumAge: Infinity,
};
function success(position) {
      var km = document.getElementById("km");
      count++;
      var lat = position.coords.latitude;
      var long = position.coords.longitude;
      if ((count)%2==1) {
        loc.after.latitude = lat;
        loc.after.longitude = long;
      } else if ((count)%2==0) {
        loc.before.latitude = lat;
        loc.before.longitude = long;
      }
      if ((count)%2 == 0 && count != 0) {
        res += haversineDistance(loc);
        km.value = res;
      }
}
function haversineDistance(coords) {
    Number.prototype.toRad = function() {
      return this * Math.PI / 180;
    }
    var lat2 = coords.before.latitude; 
    var lon2 = coords.before.longitude; 
    var lat1 = coords.after.latitude; 
    var lon1 = coords.after.longitude;
    var R = 6371; // km 
    //has a problem with the .toRad() method below.
    var x1 = lat2-lat1;
    var dLat = x1.toRad();  
    var x2 = lon2-lon1;
    var dLon = x2.toRad();  
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) + 
                    Math.cos(lat1.toRad()) * Math.cos(lat2.toRad()) * 
                    Math.sin(dLon/2) * Math.sin(dLon/2);  
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    var d = R * c; 
    return(d);
}
function stoplocation() {
  stopf = true;
}; 
function getLocation() {
    var status = document.getElementById("geostatus");
    var input = document.getElementById("km");
    loc = {
      before: {latitude: 0, longitude: 0},
      after: {latitude: 0, longitude: 0}
    }; 
    res = 0; count = 0; stopf = false;
    if(navigator.geolocation) {
        var status = document.getElementById("geostatus");
        var view = document.getElementById("view-geoinfo");
        // Styles
        input.readOnly = true;
        input.style.cursor = "not-allowed";
        status.style.color = `red`;
        view.style.display = `block`;
        status.innerHTML = "Trajet commencé (attention cette fonctionnalité est expérimental)";
        navigator.geolocation.getCurrentPosition(success, error, options);
        setInterval(function() {
            if (stopf == false) {
                navigator.geolocation.getCurrentPosition(success, error, options);
            } else {status.style.color = `green`;
            input.readOnly = false;
            input.style.cursor = "pointer";
            status.innerHTML = `Trajet terminé : ${res} Km ont étés parcourus`;return;}
        }, 8000);
    } else {
      alert("La localisation ne peut pas être utilisée sur ce navigateur");
    }
}